USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_GetReservationReceivedReport]    Script Date: 07/22/2016 20:20:01 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[hotels].[SP_GetReservationReceivedReport]') AND type in (N'P', N'PC'))
DROP PROCEDURE [hotels].[SP_GetReservationReceivedReport]
GO

USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_GetReservationReceivedReport]    Script Date: 07/22/2016 20:20:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [hotels].[SP_GetReservationReceivedReport]
	-- Add the parameters for the stored procedure here
	@hotelId int = 0,@startDate varchar(50),@endDate varchar(50),@liveFlag varchar(1)='N'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT res.Booking_Id as booking_id,Hotel_Id as hotel_id,res.Booking_Status as booking_status,res.source as source,created_time as booking_date,amendment_date as amend_date,resCon.cancelled_time as cancel_date,res.Hotel_Name as hotel_name,CONVERT(date,res.Checkin_Date) as checkin_date,CONVERT(date,res.Checkout_Date) as checkout_date
	,res.Room_Name as room_name,bp.Code_plan as code_plan,res.Plan_Name as plan_name,res.Duration_Of_Stay as length_of_stay,res.Number_Of_Rooms as number_of_room
	,res.Duration_Of_Stay as rns,res.Number_Of_Adults as number_of_adult,res.Number_Of_Childrens as number_of_children
	--,res.Total_Points as total_point,res.Total_Points_Deducted as points,res.Total_Amount as cash
	--
	/*,case when res.Plan_Type = 'Full Redemption' then res.Total_Points else 0 end as total_point
	,case when res.Plan_Type = 'Part Redemption' then res.Total_Points_Deducted else 0 end as points
	,case when res.Plan_Type = 'Part Redemption' then res.Amount_Paid else 0 end as cash
	--
	,res.Total_Points_Deducted as total_point_deducted
	,res.Total_Amount as total_cash_amount,res.Amount_Paid as deposit_paid,res.Balance_Amount as balance_amount */
	,CASE 
		WHEN res.Plan_Type='Full Cash' THEN res.Total_Amount
		WHEN res.Plan_Type='Full Redemption' THEN 0
		WHEN res.Plan_Type='Part Redemption' THEN res.Total_Amount
		ELSE 0.0 
	END as total_cash_amount
	,CASE 
		WHEN res.Plan_Type='Full Cash' THEN 0
		WHEN res.Plan_Type='Full Redemption' THEN 0
		WHEN res.Plan_Type='Part Redemption' THEN res.Total_Amount
		ELSE 0.0 
	END as cash
	,CASE 
		WHEN res.Plan_Type='Full Cash' THEN res.Amount_Paid
		WHEN res.Plan_Type='Full Redemption' THEN 0
		WHEN res.Plan_Type='Part Redemption' THEN res.Amount_Paid
		ELSE 0.0 
	END as deposit_paid
	,CASE 
		WHEN res.Plan_Type='Full Cash' THEN res.Balance_Amount
		WHEN res.Plan_Type='Full Redemption' THEN 0
		WHEN res.Plan_Type='Part Redemption' THEN res.Balance_Amount
		ELSE 0.0 
	END as balance_amount
	,CASE 
		WHEN res.Plan_Type='Full Cash' THEN 0
		WHEN res.Plan_Type='Full Redemption' THEN res.Total_Points
		WHEN res.Plan_Type='Part Redemption' THEN 0
		ELSE 0.0 
	END as total_point
	,CASE 
		WHEN res.Plan_Type='Full Cash' THEN 0
		WHEN res.Plan_Type='Full Redemption' THEN res.Total_Points_Deducted
		WHEN res.Plan_Type='Part Redemption' THEN res.Total_Points_Deducted
		ELSE 0.0 
	END as total_point_deducted
	,CASE 
		WHEN res.Plan_Type='Full Cash' THEN 0
		WHEN res.Plan_Type='Full Redemption' THEN 0
		WHEN res.Plan_Type='Part Redemption' THEN res.Total_Points_Deducted
		ELSE 0.0 
	END as points
	,res.Luxury_Tax as luxury_tax,res.Service_Tax as service_tax,res.Vat as vat,res.Total_Tax as total_tax
	,res.Guest_Id as guest_id,res.Guest_Title as guest_title,res.Guest_First_Name as first_name,res.Guest_Last_Name as last_name,res.Guest_Address1 as guest_address1,res.Guest_Address2 as guest_address2,res.Guest_Phone_Number as phone_number,res.Guest_Email_Id as email_id,res.guest_company as guest_company
	,case when res.guest_fbhandle is not null and res.guest_fbhandle != '' and res.guest_twhandle is not null and res.guest_twhandle != '' and res.guest_instahandle is not null and res.guest_instahandle != ''
		  then ''+res.guest_fbhandle+','+res.guest_twhandle+','+res.guest_instahandle
		  when res.guest_fbhandle is not null and res.guest_fbhandle != '' and res.guest_twhandle is not null and res.guest_twhandle != '' and (res.guest_instahandle is null or res.guest_instahandle = '')
		  then ''+res.guest_fbhandle+','+res.guest_twhandle
		  when res.guest_fbhandle is not null and res.guest_fbhandle !='' and res.guest_instahandle is not null and res.guest_instahandle != '' and (res.guest_twhandle is null or res.guest_twhandle = '')
		  then ''+res.guest_fbhandle+','+res.guest_instahandle
		  when res.guest_fbhandle is not null and res.guest_fbhandle != '' and (res.guest_instahandle is null or res.guest_instahandle = '') and (res.guest_twhandle is null or res.guest_twhandle = '')
		  then ''+res.guest_fbhandle
		  when (res.guest_fbhandle is null or res.guest_fbhandle = '') and (res.guest_instahandle is null or res.guest_instahandle='') and (res.guest_twhandle is not null and res.guest_twhandle != '')
		  then ''+res.guest_twhandle
		  else
			res.guest_fbhandle
	end as social_handles 
	,guestRes.Date_of_Birth as dob,res.guest_country as guest_country,res.guest_state as guest_state,res.guest_city as guest_city,res.guest_pincode as guest_pincode,
	res.Flight_Number_Arrival as flight_number_arrival,res.Arrival_Time as flight_arrival_time,res.Airport_Name_Arrival as Airport_Name_Arrival
	,res.Flight_Number_Departure as flight_number_departure,res.Departure_Time as flight_departure_time,res.Airport_Name_Departure as flight_departing_from
	--,'' as internetType,'' as internetRate,'' as internetQty,'' as diningType,'' as diningRate,'' as diningQty,'' as spaType,'' as spaRate,'' as spaQty
	,(select sum(addOn.quantity) from r_booking_add_on_details addOn where addOn.booking_id=res.Booking_Id and res.Hotel_id=addOn.Hotel_id and res.Hotel_id= @hotelId and UPPER(addOn.add_on_type) = 'INTERNET') as internet_qty 
	,(select sum(addOn.amount) from r_booking_add_on_details addOn where addOn.booking_id=res.Booking_Id and res.Hotel_id=addOn.Hotel_id and res.Hotel_id= @hotelId and UPPER(addOn.add_on_type) = 'INTERNET') as internet_rate
	,(select distinct addOn.add_on_type from r_booking_add_on_details addOn where addOn.booking_id=res.Booking_Id and res.Hotel_id=addOn.Hotel_id and res.Hotel_id= @hotelId and UPPER(addOn.add_on_type) = 'INTERNET') as internet_type
	,(select sum(addOn.quantity) from r_booking_add_on_details addOn where addOn.booking_id=res.Booking_Id and res.Hotel_id=addOn.Hotel_id and res.Hotel_id= @hotelId and UPPER(addOn.add_on_type) = 'DINING') as dining_qty
	,(select sum(addOn.amount) from r_booking_add_on_details addOn where addOn.booking_id=res.Booking_Id and res.Hotel_id=addOn.Hotel_id and res.Hotel_id= @hotelId and UPPER(addOn.add_on_type) = 'DINING') as dining_rate
	,(select distinct addOn.add_on_type from r_booking_add_on_details addOn where addOn.booking_id=res.Booking_Id and res.Hotel_id=addOn.Hotel_id and res.Hotel_id= @hotelId and UPPER(addOn.add_on_type) = 'DINING') as dining_type
	,(select sum(addOn.quantity) from r_booking_add_on_details addOn where addOn.booking_id=res.Booking_Id and res.Hotel_id=addOn.Hotel_id and res.Hotel_id= @hotelId and UPPER(addOn.add_on_type) = 'SPA') as spa_qty
	,(select sum(addOn.amount) from r_booking_add_on_details addOn where addOn.booking_id=res.Booking_Id and res.Hotel_id=addOn.Hotel_id and res.Hotel_id= @hotelId and UPPER(addOn.add_on_type) = 'SPA') as spa_rate
	,(select distinct addOn.add_on_type from r_booking_add_on_details addOn where addOn.booking_id=res.Booking_Id and res.Hotel_id=addOn.Hotel_id and res.Hotel_id= @hotelId and UPPER(addOn.add_on_type) = 'SPA') as spa_type
	,perf.Additional_Request as additional_request
	,case when perf.smoking is null or perf.smoking = 'N' or perf.smoking = '' then 'No' else 'Yes' end as smoking
	,case when perf.non_smoking is null or perf.non_smoking = 'N' or perf.non_smoking = '' then 'No' else 'Yes' end as non_smoking
	,case when perf.inter_connect_rooms is null or perf.inter_connect_rooms = 'N' or perf.inter_connect_rooms = '' then 'No' else 'Yes' end as inter_connect_rooms
	,case when perf.higher_floor is null or perf.higher_floor = 'N' or perf.higher_floor = '' then 'No' else 'Yes' end as higher_floor
	,case when perf.lower_floor is null or perf.lower_floor = 'N' or perf.lower_floor = '' then 'No' else 'Yes' end as lower_floor
	,case when perf.early_arrival is null or perf.early_arrival = 'N' or perf.early_arrival = '' then 'No' else 'Yes' end as early_arrival
	,case when perf.early_arr_time is null or perf.early_arr_time = 'N' or perf.early_arr_time = '' then 'No' else perf.early_arr_time end as early_arr_time
	,case when perf.late_arrival is null or perf.late_arrival = 'N' or perf.late_arrival = '' then 'No' else 'Yes' end as late_arrival
	,case when perf.late_arr_time is null or perf.late_arr_time = 'N' or perf.late_arr_time = '' then 'No' else late_arr_time end as late_arr_time
	,res.CCA_Status_Code as cc_avenue_response
	,res.Txn_Date as transaction_date,res.CCA_Payment_Mode as payment_mode,res.PRN as prn,res.BID as bid,res.PID as pid,res.hotel_type as hotel_type
	,res.CCA_Bank_Ref_No as cc_bank_ref_no,res.CCA_Billing_Telephone as cc_billing_telephone,res.CCA_Card_Name as cc_card_name,res.CCA_Delivery_State as cc_delivery_state
	,res.CCA_Failure_Message as cc_failure_msg,res.CCA_Status_Code as cc_status_code,res.CCA_Status_Message as cc_status_msg,res.CCA_Tracking_Id as cc_tracking_id,res.CCA_Txn_Amount as cc_txn_amount,res.CCA_Vault as cc_vault
	from ReservationDetails res 
	left outer join reservation_cancel_details resCon on resCon.Booking_Id = res.Booking_Id
	inner join b_plan bp on bp.id_hotel=res.Hotel_Id and bp.id_plan=res.Plan_Id
	inner join r_preferences perf on perf.booking_id = res.Booking_Id
	left outer join Register guestRes on guestRes.Guest_Id=res.Guest_Id
	where Hotel_Id=@hotelId and ((@liveFlag!='Y' and convert(date,res.created_time) between @startDate and @endDate) or (@liveFlag='Y' and convert(date,res.Checkin_Date) between @startDate and @endDate))
END

GO


