USE [welcomgroup]
GO

/****** Object:  Trigger [Trg_Upd_RoomAvail]    Script Date: 07/05/2016 19:51:47 ******/
IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[Trg_Upd_RoomAvail]'))
DROP TRIGGER [dbo].[Trg_Upd_RoomAvail]
GO

USE [welcomgroup]
GO

/****** Object:  Trigger [dbo].[Trg_Upd_RoomAvail]    Script Date: 07/05/2016 19:51:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[Trg_Upd_RoomAvail] ON [dbo].[b_room] 
FOR UPDATE
AS

DECLARE @HotelID INT,@RoomID INT,@NoRoom INT,@strSale CHAR,@intMaxBooking INT,@User varchar(10)

/* local vaiables required*/
DECLARE @curdate DATETIME
DECLARE @enddate DATETIME
DECLARE @intNoRoom INT


SELECT @intMaxBooking=no_maxbookingdays FROM a_system 

SELECT @HotelID=id_hotel,@RoomID=Id_room,@NoRoom=No_room,@strSale=flg_sale,@User=Lst_mod_usr from INSERTED

SET @curdate=getdate()
	

	SET @enddate=DATEADD(day,@intMaxBooking,@curdate)
	
	
	WHILE (@curdate<@enddate)
	BEGIN
	
		IF exists(SELECT id_room from b_room_avail where id_room=@RoomID and id_hotel=@HotelID and convert(date,date_avail)=convert(date,@curdate)) 
		    BEGIN
		    
				SELECT @intNoRoom = No_inv - No_avail from b_room_avail where id_room=@RoomID and id_hotel=@HotelID and 
				convert(date,date_avail)=convert(date,@curdate)
			     
				UPDATE  B_ROOM_AVAIL SET No_inv=@NoRoom, No_avail=@NoRoom-@intNoRoom,Flg_status='O' where id_room=@RoomID and id_hotel=@HotelID and convert(date,date_avail)=convert(date,@curdate)
		    
		    END
		ELSE
		    BEGIN
			IF @strSale='Y'
			BEGIN
				INSERT INTO B_ROOM_AVAIL VALUES(@RoomID,@HotelID,convert(date,@curdate),@NoRoom,@NoRoom-@intNoRoom,'O',@User,convert(date,getdate()))				
			END
		    END

		SELECT @curdate=DATEADD(day,1,@curdate)
	END	
	


GO


