USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_GetAllEmailCategory]    Script Date: 07/05/2016 14:05:25 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[hotels].[SP_GetAllEmailCategory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [hotels].[SP_GetAllEmailCategory]
GO

USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_GetAllEmailCategory]    Script Date: 07/05/2016 14:05:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE Procedure [hotels].[SP_GetAllEmailCategory]
AS
Begin
select distinct(catagory) FROM [welcomgroup].[dbo].[m_email_details] where catagory IS NOT NULL AND catagory != 'Website'
End

GO


