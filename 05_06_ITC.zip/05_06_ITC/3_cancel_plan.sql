USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_cancel_plan]    Script Date: 07/05/2016 19:53:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[hotels].[SP_cancel_plan]') AND type in (N'P', N'PC'))
DROP PROCEDURE [hotels].[SP_cancel_plan]
GO

USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_cancel_plan]    Script Date: 07/05/2016 19:53:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Description:	<To calculate the cancel amount>
-- =============================================
CREATE PROCEDURE [hotels].[SP_cancel_plan]
@bookingId numeric(18,0),
@owsCancellationId varchar(50),
@cancelReason varchar(100),
@cancelDesc varchar(5000)
-- @result int output
AS
BEGIN

    Declare @planId numeric(18,0),@checkInDate varchar(20),@cancelDays numeric(18,0),@cancelType varchar(1),
    @roomId numeric(18,0),@checkOutDate varchar(20),@hotelId numeric(18,0),
	 @refundAmount numeric(18,2),@amountPaid numeric(18,2),@cancelValue numeric(18,2),
	 @rateAmount numeric(18,2),@noOfRooms int,@currentHour int,@cancelHour int,@cancelTime varchar(10),
	 @hotelType varchar(50),@hotelCode varchar(20),@rateCode varchar(20),@foundBookingId int
 	
 	declare @currentDateFlag varchar(1)
	set @currentDateFlag = 'Y'; 
	create table #tempRefundDetail
	(	refundAmount numeric(18,2),
		cancellationCharges numeric(18,2),
		currDateRefundAmount numeric(18,2),
		currDateCancelCharges numeric(18,2),
		planCancelDate varchar(50),
		planCancelTime varchar(10),
		amountPaid numeric(18,2),
		bookingId int,
		cancelType varchar(1),
		cancelValue numeric(18,2)
	)
	INSERT INTO #tempRefundDetail(refundAmount,cancellationCharges,currDateRefundAmount,currDateCancelCharges,amountPaid,planCancelDate,planCancelTime,bookingId,cancelType,cancelValue)
	EXEC [hotels].[SP_GetRefundableAmountByBookingId] @bookingId,@currentDateFlag
	select @refundAmount = currDateRefundAmount,@foundBookingId = bookingId from #tempRefundDetail
	if(@foundBookingId is not null and @foundBookingId > 0 and @foundBookingId = @bookingId)
	begin
		Update ReservationDetails SET OWS_Cancellation_Id = @owsCancellationId,is_cancelled = 'Y' where Booking_Id = @bookingId
	    
		INSERT INTO [welcomgroup].[dbo].[reservation_cancel_details]
			   ([Booking_Id]
			   ,[refunded_amount]
			   ,[cancel_reason]
			   ,[description]
			   ,[cancelled_time])
		 VALUES(@bookingId,@refundAmount,@cancelReason,@cancelDesc,getdate())
		 -- End of ReservationDetails updation and storing feedback if (@Result !=4)
	end
	
	if(@owsCancellationId is null or @owsCancellationId = '' or @owsCancellationId = '0')
	begin
	    EXEC [hotels].[SP_CancelRoomInventory] @bookingId
	end
	
	select @refundAmount as refundAmount,@foundBookingId as bookingId
end


GO


