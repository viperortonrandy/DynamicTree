USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_CancelRoomInventory]    Script Date: 07/05/2016 19:53:56 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[hotels].[SP_CancelRoomInventory]') AND type in (N'P', N'PC'))
DROP PROCEDURE [hotels].[SP_CancelRoomInventory]
GO

USE [welcomgroup]
GO

/****** Object:  StoredProcedure [hotels].[SP_CancelRoomInventory]    Script Date: 07/05/2016 19:53:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Description:	<Update room inventory after cancel booking>
-- =============================================
CREATE PROCEDURE [hotels].[SP_CancelRoomInventory]
@bookingId numeric(18,0)

AS
BEGIN
    Declare @hotelId numeric(18,0)
    Declare @noOfRooms numeric(18,0)
    Declare @roomId numeric(10,0)
    Declare @checkInDate varchar(20)
    Declare @checkOutDate varchar(20)
    
	Select @hotelId=CAST(Hotel_Id as numeric(18,0)),@roomId=Room_Id, @noOfRooms=Number_Of_Rooms,
	@checkInDate=Checkin_Date, @checkOutDate=Checkout_Date  from dbo.ReservationDetails  
    
    Update b_room_avail set No_avail = No_avail + @noOfRooms where Id_hotel=@hotelId and id_room=@roomId
    and Date_avail >= @checkInDate and Date_avail < @checkOutDate 
    
END

GO


